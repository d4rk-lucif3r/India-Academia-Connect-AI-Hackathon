- train folder
You can find the NON TEXT images (-ve class) in the ‘background’ sub folder.
TEXT images (+ve class) are stored in ‘hi’ sub folders.

- test folder
This folder contains images to be classified. Label with 0 for NON TEXT images.
Label with 1 for TEXT images. Generate a JSON File and submit. create_sample_output.py will generate a sample template file for you which can be used as reference on how the submission looks like.

The material here is derived from the Kaggle competion : https://www.kaggle.com/c/padhai-text-non-text-classification-level-4b
